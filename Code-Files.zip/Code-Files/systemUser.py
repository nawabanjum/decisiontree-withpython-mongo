class SystemUser:
    def __init__(self,username,Password):
        self.userName=username
        self.Password=Password

