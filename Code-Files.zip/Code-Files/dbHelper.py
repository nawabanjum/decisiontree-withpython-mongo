

################################################################################################
## Start off with imports that we're going to need for mongo :
import pymongo as m

class DbHelper: # Create a DbHelper Class for mongo Operation
    def __init__(self):
        # Defaul Mongo server port ,and make connection private for outside access
        try:
            myclient = m.MongoClient("mongodb://localhost:27017/")
            self.dataBase  = myclient["CMP6221"]
            print("Database connected!")
        except Exception as e:
            print("Database connection error! Please make sure you have mongo installed!")
            raise e

    # Define a generic method to load data from the Database
    def load_data(self, collectionName):
        return self.dataBase[collectionName]

    def register_user(self,name,password):
        self.dataBase.add_user(name,password)

    def authenticate(self,name,password):
        self.dataBase.authenticate(name, password)

    # Define a generic method to Save data in the bulk form into the  Database
    def save_bulk_data(self,collectionName,data):
        try:
            col=self.dataBase[collectionName]
            col.insert_many(data)
        except:
             print ("No hosts found")

    # Define a generic method to Save data as a one record into the  Database
    def save_data(self,collectionName,data):
        try:

            col = self.dataBase[collectionName]
            col.insert_one(data)
        except col.errors.ConnectionFailure :
             print("No hosts found ")
        except col.errors.AttributeError :
             print ("Error Json is not fully formatted")













