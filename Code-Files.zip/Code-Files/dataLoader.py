import dbHelper
import json
import pandas as pd
from pandas import DataFrame
class DataLoader:
    def __init__(self):

        self.__db = dbHelper.DbHelper()  #initialization Db Class
        self.__dataSetName = "Dataset"


    #authenticate_user Database User
    def authenticate_user(self,username,password):
        try:
           self.__db.authenticate(username,password)
           return  True
        except Exception as e:
            return  False

        # creatin Database User

    def registeruser(self, username, password):
        try:
            self.__db.register_user(username, password)
        except Exception as e:
            print("Database connection error! Please make sure you have mongo installed!")
            raise e
    # Converting to the DataFrame

    def loading_data(self):
        dataset=self.__db.load_data(self.__dataSetName).find({})

        if dataset.count()>0:#if database table has already imported csv data then simply loading dataset as a datafram

            print("returning data from the databse")
            return DataFrame(list(dataset))
        else:#if database collection has not anything then firstly pushing the csv into mongo and returning

            print("No data found in Mongo collection ,process start to save data")
            self.__push_csv_data()
            return DataFrame(list(self.__db.load_data(self.__dataSetName).find({})))

    def __push_csv_data(self):#importing diabetes.csv file

        file_name = 'diabetes.csv' #File name
        col_names = ['pregnant', 'glucose', 'bp', 'skin', 'insulin', 'bmi', 'pedigree', 'age', 'label']
        # read in the data
        data = pd.read_csv(file_name,header=None, names=col_names)  #Reading csv data
        data = data.drop([0, len(data) - 1], axis=0) #removing last row, as it has null data

        data_json = json.loads(data.to_json(orient='records'))# converting into json model
        if len(data_json)>0:    #checking if data json has data or not

            self.__db.save_bulk_data(self.__dataSetName,data_json)