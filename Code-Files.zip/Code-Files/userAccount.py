from random import random
from tkinter import *
import securitycheck
import os
import dbHelper
#defining login function
def validate_login():
    #getting form data
    uname=username.get()
    pwd=password.get()
    #i'm setting nawab as a default password and converting it as a hashed
   #defaultPassword = securitycheck.securitycheck.hash_password("nawab")
    #applying empty validation
    if uname=='' or pwd=='':
        message.set("fill the empty field!!!")
    else:
        Validate_dbUser(pwd,uname)



def Validate_dbUser(pwd,uname):
    db = dbHelper.DbHelper()
    hashedPassword = securitycheck.securitycheck.hash_password(pwd)
    print(hashedPassword)
    model = db.load_data("SystemUser").count_documents({"userName": uname, "Password": hashedPassword})
    print(model)
    if  model!=0:
        message.set("Login success")
        login_screen.destroy()
        os.system('index.py')
    else:
        message.set("You have entered wrong! username or password!!!")



def Goto_Register():
    login_screen.destroy()
    os.system('register.py')

#defining loginform function
def Login():
    global login_screen
    login_screen = Tk()
    #Setting title of screen
    login_screen.title("Login")
    #setting height and width of screen
    login_screen.geometry("300x250")
    #declaring variable
    global  message;
    global username
    global password
    global labelColor
    username = StringVar()
    password = StringVar()
    message=StringVar()
    labelColor=StringVar()

    #Creating layout of login form
    Label(login_screen,width="300", text="Please enter valid details", bg="black",fg="white").pack()
    #Username Label
    Label(login_screen, text="Username * ").place(x=20,y=40)
    #Username textbox
    Entry(login_screen, textvariable=username).place(x=90,y=42)
    #Password Label
    Label(login_screen, text="Password * ").place(x=20,y=80)
    #Password textbox
    Entry(login_screen, textvariable=password ,show="*").place(x=90,y=82)
    #Label for displaying login status[success/failed]
    Label(login_screen, text="",textvariable=message).place(x=95,y=100)
    #Login button
    Button(login_screen, text="Login", width=15, height=1,command=validate_login).place(x=105,y=130)
    Button(login_screen, text="Register", width=15, height=1, command=Goto_Register).place(x=105, y=180)
    login_screen.mainloop()
#calling function Loginform
Login()

