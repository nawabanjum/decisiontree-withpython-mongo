import dataLoader  # importing Data Loader
from sklearn.tree import DecisionTreeClassifier  # Import Decision Tree Classifier
from sklearn.model_selection import train_test_split  # Import train_test_split function
from sklearn import metrics  # Import scikit-learn metrics module for accuracy calculation
import pydotplus
from sklearn import tree
import matplotlib.pyplot as plt
import matplotlib.image as pltimg



class BuildingTree:

    def __init__(self,data):
        self.feature_cols = ['pregnant', 'insulin', 'bmi', 'age', 'glucose', 'bp', 'pedigree']
        self.X = data[self.feature_cols]  # Features
        self.y = data.label  # Target variable
    def __spliting_dataset(self):
        # Split dataset into training set and test set
        X_train, X_test, y_train, y_test = train_test_split(self.X, self.y, test_size=0.3, random_state=1)  # 70% training and 30% test
        return X_train, X_test, y_train, y_test
    def creating_tree_display_graph(self) :
        X_train, X_test, y_train, y_test = self.__spliting_dataset()#Calling spliting dataset private funtion
        clf= DecisionTreeClassifier(criterion="entropy", max_depth=3)
        # criterion="entropy", max_depth=3
        # Train Decision Tree Classifer
        #print(X_train, X_test, y_train, y_test)
        clf = clf.fit(X_train, y_train)
        # Predict the response for test dataset
        y_pred = clf.predict(X_test)
        # Model Accuracy, how often is the classifier correct?
        print("Accuracy:", metrics.accuracy_score(y_test, y_pred))

        t = tree.export_graphviz(clf,
                                 filled=True, rounded=True,
                                 special_characters=True,
                                 feature_names=self.feature_cols)
        graph = pydotplus.graph_from_dot_data(t)
        graph.write_png('decisiontree.png')
        img = pltimg.imread('decisiontree.png')
        plt.imshow(img)
        plt.show()



if __name__ == '__main__':
    #Laoding Mongo data
    loader = dataLoader.DataLoader()
    isLogin=False
    #this is not real case, so just doing auth here ,is auth fail then creating user.
    if (loader.authenticate_user("anjum1", "anjum")):#check Auth
        isLogin=True
        print("Database user Connected Successfully!")
    else:
        print("Creating new Database user!")
        loader.registeruser("anjum", "anjum")#registring user
        print("New Database user Connected Successfully!")
        loader.authenticate_user("anjum", "anjum")
        isLogin = True

    if(isLogin):
        data = loader.loading_data()
        #Passed Data in the constructor of  building tree
        obj_BuildingTree=BuildingTree(data)
        #used the object and call the method(function) to build and display
        obj_BuildingTree.creating_tree_display_graph()
    else:
        print("Login failed! please contact with Admin Team")

