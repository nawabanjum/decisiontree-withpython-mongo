from random import random
from tkinter import *
import securitycheck
import os
import dbHelper



# defining login function
def Register():
    # getting form data
    uname = username.get()
    pwd = password.get()


    # applying empty validation
    if uname == '' or pwd == '':
        message.set("fill the empty field!!!")
    else:
        #making password as hashed
        hashedPassword = securitycheck.securitycheck.hash_password(pwd)
        print(pwd)
        print(hashedPassword)

        usermodel={"userName":uname,
                              "Password":hashedPassword}
        db=dbHelper.DbHelper()
        db.save_data(collectionName="SystemUser",data=usermodel)
        message.set("New user registered successfully")
        username.set("")
        password.set("")




def GotoLogin():
    register_screen.destroy()
    os.system('userAccount.py')


# defining loginform function
def RegisterForm():
    global register_screen
    register_screen = Tk()
    # Setting title of screen
    register_screen.title("Register a new system user")
    # setting height and width of screen
    register_screen.geometry("300x250")
    # declaring variable
    global message;
    global username
    global password
    global labelColor
    username = StringVar()
    password = StringVar()
    message = StringVar()
    labelColor = StringVar()

    # Creating layout of login form
    Label(register_screen, width="300", text="Please enter valid details", bg="black", fg="white").pack()
    # Username Label
    Label(register_screen, text="Username * ").place(x=20, y=40)
    # Username textbox
    Entry(register_screen, textvariable=username).place(x=90, y=42)
    # Password Label
    Label(register_screen, text="Password * ").place(x=20, y=80)
    # Password textbox
    Entry(register_screen, textvariable=password, show="*").place(x=90, y=82)
    # Label for displaying login status[success/failed]
    Label(register_screen, text="", textvariable=message).place(x=95, y=100)
    Button(register_screen, text="Register", width=15, height=1, command=Register).place(x=105, y=130)
    Button(register_screen, text="Go to Login", width=15, height=1, command=GotoLogin).place(x=105, y=180)

    register_screen.mainloop()


# calling function RegisterForm
RegisterForm()

